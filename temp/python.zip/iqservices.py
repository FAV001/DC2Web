#!/usr/bin/env python
# -*- coding: utf8 -*-
import os, cgi
import urllib
import json





pwd  = '11031985'
login = 'BestProTop'
address = 'Москва Кравченко 12'

URL  = 'http://iqdq.ru/services/IQDQ/SearchAddressDetail?addr='+ address +'&login='+login+'&pwd='+pwd

result = urllib.urlopen(URL).read()


print result
